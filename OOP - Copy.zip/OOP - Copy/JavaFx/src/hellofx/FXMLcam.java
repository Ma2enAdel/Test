package hellofx;

public @interface FXMLcam {

}
