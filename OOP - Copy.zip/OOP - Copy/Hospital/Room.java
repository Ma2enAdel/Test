package Hospital;

public class Room {

    int RoomNumber;

    public void setRoomNumber(int RoomNumber){
        this.RoomNumber = RoomNumber;
    }

    public int getRoomNumber(){
        return RoomNumber;
    }
    
}
