package Hospital;

public class Nurse extends Employee{
    
}
