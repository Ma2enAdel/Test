package Hospital;

public class Doctor extends Employee {
    
}
